angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $ionicHistory, $timeout, $ionicLoading, $ionicPopup, $rootScope, $state, $location, $http, storage, $localStorage) {


    
  $rootScope.goto = function(pagina){
        //$rootScope.showLoadingPaginas = true;
        //$ionicLoading.show();
        $state.go(pagina);
  } 

  $rootScope.backCarrinho = function(){
        if($state.current.name == "app.categorias"){
            $ionicHistory.goBack(-1);
        }else if($state.current.name == "app.produtospedido"){
            $ionicHistory.goBack(-2);
        }else if($state.current.name == "app.subprodutospedido"){
            $ionicHistory.goBack(-3);
        }else{
            $state.go('app.novopedido');
        }
  }

    $rootScope.alerta = function(titulo, texto){
        navigator.notification.alert(texto,null,titulo,'OK');
    }

    $rootScope.clickNovoPedido = function(){
        if($rootScope.arrayPedido != undefined){
            $rootScope.arrayPedido = undefined;
            $rootScope.itensPedido = [];
            $rootScope.cpfClientePedido = undefined;
            $rootScope.nomeClientePedido = undefined;
        }
        $rootScope.goto('app.novopedido');
    }

    $rootScope.menuBuscaClientes = function(){
        $rootScope.buscaClientesPedido = 0;
        $rootScope.goto('app.buscaclientes');
    }

    $rootScope.clickAdicionarNovo = function(){
        $rootScope.buscaClientes();
    }

    $rootScope.clickBtSalvarCliente = function(){
        $rootScope.clickSalvar($rootScope.cadastro);
    }


    $rootScope.bottomMenu = false;
    $rootScope.logoLogin = false;
    $rootScope.listaProdutos = [];
    $rootScope.showLoading = false;
    //$rootScope.showLoadingPaginas = true;
    $rootScope.valorProgress = 0;
    $rootScope.url = 'http://apiteste.sementesfeltrin.com.br/';
    //$scope.valorSoma = 0;
    $rootScope.labelCarregando = "Carregando dados, aguarde...";

    $rootScope.showOpcoes = 1;

    console.log($rootScope.url);

    console.log($localStorage.pedidosSalvos);

    if($localStorage.pedidosSalvos == undefined)
            $localStorage.pedidosSalvos = [];

    if($localStorage.clientesTemp == undefined)
            $localStorage.clientesTemp = [];

        

     // CRIA O ARRAY PARA O LOGIN
      $scope.loginData = {};
      console.log($localStorage.logado);
        
      // ABRE O MODAL DE LOGIN
      $scope.showModalLogin = function() {
        // CRIA O MODAL CHAMANDO O TEMPLATE
        if($rootScope.larguraTela >= 830){
            $ionicModal.fromTemplateUrl('templates/login.html', {
                scope: $scope,
                animation:'none',
                hardwareBackButtonClose: false,
                backdropClickToClose: false,
              }).then(function(modal) {
                $scope.modal = modal;
              });
            $timeout(function() {
                $scope.modal.show();
            }, 50);
            
        }else{
            $ionicModal.fromTemplateUrl('templates/login.html', {
                scope: $scope,
                hardwareBackButtonClose: false,
                backdropClickToClose: false,
              }).then(function(modal) {
                $scope.modal = modal;
              });
            $timeout(function() {
                $scope.modal.show();
            }, 50);   
        }
            
      };

      // ESCONDE O MODAL DE LOGIN
      $scope.closeModalLogin = function() {
        $scope.modal.hide();
      };
      console.log($localStorage.logado);



    $scope.clickLogar = function(dadosLogin){
        console.log(dadosLogin);
        var retornoLogin = $rootScope.login(dadosLogin.usuario, dadosLogin.senha);
    }

    document.addEventListener('deviceready',function(){

        $rootScope.larguraTela = window.screen.width+30;
        //alert($rootScope.larguraTela);


        document.addEventListener('backbutton', function (event) {
            console.log($state.current.name);
            if($state.current.name == 'app.buscaclientes'){
                $rootScope.showOpcoes = 1;
            }else if($state.current.name == 'app.cadastroclientes'){
                $rootScope.showOpcoes = 2;
            }
            event.preventDefault();
            event.stopPropagation();
        }, false);

        var doCustomBack = function() {
             console.log($state.current.name);
            if($state.current.name == 'app.buscaclientes'){
                $rootScope.showOpcoes = 1;
                $ionicHistory.goBack();
            }else if($state.current.name == 'app.cadastroclientes'){
                $rootScope.showOpcoes = 2;
                $ionicHistory.goBack();
            }else if($state.current.name == 'app.home'){
                navigator.app.exitApp();
            }else{
                $ionicHistory.goBack();
            }
        };

        // override soft back
        var oldSoftBack = $rootScope.$ionicGoBack;
        $rootScope.$ionicGoBack = function() {
            doCustomBack();
        };
        var deregisterSoftBack = function() {
            $rootScope.$ionicGoBack = oldSoftBack;
        };


        $scope.deslogar = function(){
            $localStorage.logado = undefined;
            $localStorage.usuario = "";
            $localStorage.senha = "";
            $localStorage.nomeVendedor = '';
            $rootScope.nomeVendedor = '';

            $scope.showModalLogin();

            //navigator.app.exitApp();
        }

        $rootScope.enviaDadosTemp = function(index){

            console.log('entrou na funcao: '+index);
            console.log('tamanho array temp: '+$localStorage.clientesTemp.length);

            if(index < $localStorage.clientesTemp.length){
                var url = $rootScope.url+'cliente/Novo';
                $http.post(url, $localStorage.clientesTemp[index]).then(function(resposta){
                    console.log(resposta);
                    if(resposta.statusText == "OK"){
                        $ionicHistory.goBack();

                        if($localStorage.clientesTemp.length == 1)
                            $localStorage.clientesTemp = [];
                        else
                            var removed = $localStorage.clientesTemp.splice(index+1, 1);

                        index++;

                        if($localStorage.clientesTemp.length > 0){
                            $rootScope.enviaDadosTemp(index);
                        }

                    }
                }, function(err) { $rootScope.alerta('Cadastro Cliente', 'Houve um problema, verifique sua internet!');});
            }else{

            }
            
        }

        $scope.sincronizarDados = function(){
            var myPopup = $ionicPopup.show({
              //template: '<input type="password" ng-model="data.wifi">',
              title: 'Deseja realmente sincronizar os dados? Isso pode demorar alguns minutos',
              //subTitle: 'Please use normal things',
              scope: $scope,
              buttons: [
                
                {
                  text: 'Sim',
                  type: 'button-positive',
                  onTap: function(e) {
                    if(navigator.connection.type == Connection.NONE) {
                        navigator.notification.alert('Sua internet não está ativa, você não pode sincronizar os dados!',null,'Enviar Dados','OK');
                    }else if(navigator.connection.type == Connection.CELL_3G){
                        navigator.notification.alert('Você não pode sincronizar os dados pela conexão 3G!',null,'Enviar Dados','OK');
                    }
                    else{
                        $localStorage.produtos = [];
                        $localStorage.linhas = [];
                        $localStorage.categorias = [];
                        $localStorage.subcategorias = [];
                        $localStorage.clientes = [];
                        $localStorage.produtosPedido = [];
                        $localStorage.linhasPedido = [];
                        $localStorage.categoriasPedido = [];
                        $localStorage.tamanhoProdutos = 0;
                        $rootScope.carregaDados();
                    }
                    $timeout(function(){
                      myPopup.close();
                    }, 200);
                  }
                },
                {
                  text: 'Não',
                  type: 'button-calm',
                  onTap: function(e) {
                    //$scope.getCamera();
                  }
                }
              ]
            });

            myPopup.then(function(res) {
              //alert('Tapped!'+res);
            });

        }

        $rootScope.login = function(idVendedor, senha, simples){
            var url = $rootScope.url+'?usuario='+idVendedor+'&senha='+senha;
            $http.get(url).then(function(resposta) {

                console.log("resposta login: "+resposta);
                //$scope.getDadosPedido();
                if(resposta.data.Id == undefined){
                $rootScope.alerta('Login', resposta.data);
                }else{

                    if(simples == 1){
                        $localStorage.logado = 1;
                        $localStorage.nomeVendedor = resposta.data.Nome;
                        $rootScope.nomeVendedor = resposta.data.Nome;
                        $localStorage.usuario = idVendedor;
                        $localStorage.senha = senha;
                    }else{
                        $localStorage.logado = 1;
                        $localStorage.nomeVendedor = resposta.data.Nome;
                        $localStorage.ComissaoVariavel = resposta.data.ComissaoVariavel;
                        $rootScope.nomeVendedor = resposta.data.Nome;
                        $localStorage.usuario = idVendedor;
                        $localStorage.senha = senha;
                        /*$localStorage.produtos = [];
                        $localStorage.linhas = [];
                        $localStorage.categorias = [];
                        $localStorage.subcategorias = [];
                        $localStorage.clientes = [];
                        $rootScope.arrayGeralClientes = [];*/
                        $rootScope.carregaDados();
                    }
                

                    console.log('tamanho array temp: '+$localStorage.clientesTemp.length);

                    if($localStorage.clientesTemp.length > 0){
                        $rootScope.enviaDadosTemp(0);
                    }

                    $scope.closeModalLogin();

                }

            }, function(err) {  if(simples != 1) $rootScope.alerta('Erro', 'Não foi possível logar, verifique sua internet.'); });
        }

        $rootScope.carregaDados = function(){
            if($localStorage.produtos == null || $localStorage.produtos == undefined|| $localStorage.produtos.length == 0 || $localStorage.tamanhoProdutos == undefined ||$localStorage.tamanhoProdutos < $localStorage.produtos.length){
                navigator.splashscreen.hide();
                $rootScope.showLoading = true;
                if($localStorage.produtos == undefined){
                    $localStorage.produtos = [];
                    $localStorage.linhas = [];
                    $localStorage.categorias = [];
                    $localStorage.subcategorias = [];
                    $localStorage.clientes = [];
                    $localStorage.produtosPedido = [];
                    $localStorage.linhasPedido = [];
                    $localStorage.categoriasPedido = [];
                    $localStorage.SubLinhas = [];
                    $localStorage.tamanhoProdutos = 0;
                }
                else{
                    $localStorage.produtos = [];
                    $localStorage.linhas = [];
                    $localStorage.categorias = [];
                    $localStorage.subcategorias = [];
                    $localStorage.clientes = [];
                    $localStorage.produtosPedido = [];
                    $localStorage.linhasPedido = [];
                    $localStorage.categoriasPedido = [];
                    $localStorage.SubLinhas = [];
                }

                console.log($localStorage.tamanhoProdutos);

                var url = $rootScope.url+'catalogo/obter?Id=0';
                $http.get(url).then(function(resposta) {
                    console.log(resposta);
                    

                    $localStorage.produtos = [];
                    $localStorage.linhas = [];
                    $localStorage.categorias = [];
                    $localStorage.subcategorias = [];

                    $rootScope.getClientes();
                    $scope.getDadosPedido();

                    //storage.add(resposta);
                    //storage.addlinhas($localStorage.produtos, $localStorage.linhas, 'IdDaLinha', 'Linha');
                    //storage.addcategorias($localStorage.produtos, $localStorage.categorias, 'IdDaCategoria', 'Categoria', 'IdDaLinha', 'Linha');


                }, function(err) { $rootScope.alerta('Erro', 'Não foi possível carregar os dados, verifique sua internet.'); });
            }else{

                //$rootScope.showLoadingPaginas = true;
                if($rootScope.arrayGeralClientes == undefined){
                  $rootScope.arrayGeralClientes = [];
                  for (var i=0; i < $localStorage.clientes.length; i++) {
                    console.log($localStorage.clientes[i]);
                    $scope.arrayGeralClientes.push({id:$localStorage.clientes[i]['id'], cpf:$localStorage.clientes[i]['CpfCnpj'], nome:$localStorage.clientes[i]['Nome']});
                    //$scope.$apply();
                    if(i == $localStorage.clientes.length-1)
                            $rootScope.showLoadingPaginas = false;
                            navigator.splashscreen.hide();
                            $rootScope.showLoading = false;
                  };
                  $rootScope.showLoadingPaginas = false;
                }else{
                  navigator.splashscreen.hide();
                  $rootScope.showLoadingPaginas = false;
                }
                //$scope.$apply();

            }
        };

        if($localStorage.logado != 1){
            $scope.showModalLogin();
            navigator.splashscreen.hide();
            $scope.dadosLogin = {usuario: "", senha: ""};
          }else{
            navigator.splashscreen.hide();
            //$rootScope.showLoadingPaginas = true;
            $rootScope.idVendedor = $localStorage.usuario;
            $rootScope.senha = $localStorage.senha;
            $rootScope.nomeVendedor = $localStorage.nomeVendedor;    
                    
            $rootScope.login($rootScope.idVendedor, $rootScope.senha);
          }

    },false);

    $scope.getDadosPedido = function(){

        var url = $rootScope.url+'listadepreco/obterporvendedor?id='+$localStorage.usuario;
        //var url = $rootScope.url+'listadepreco/obter?Id=0';
        $http.get(url).then(function(resposta) {
            $localStorage.produtosPedido = [];
            console.log("resposta dados pedido: "+resposta.data);
            $localStorage.produtosPedido = resposta.data;

            $rootScope.showLoadingPaginas = false;
            $rootScope.showLoading = false;

            storage.addlinhaspedido($localStorage.produtosPedido, $localStorage.linhasPedido, 'Id', 'Descricao');
            storage.addcategoriaspedido($localStorage.produtosPedido, $localStorage.categoriasPedido, 'CodigoDoGrupo', 'DescricaoDoGrupo', 'Id', 'Descricao');
            //storage.addclientes(resposta);

        }, function(err) { $rootScope.alerta('Erro', 'Não foi possível carregar os dados, verifique sua internet.'); });
    }


    $rootScope.getClientes = function(){
        var url = $rootScope.url+'cliente/obterporvendedor?Id='+$localStorage.usuario;
        $http.get(url).then(function(resposta) {

            $localStorage.clientes = [];
            $localStorage.clientesGeral = [];

            $rootScope.getClientesGeral();

            storage.addclientes(resposta);

        }, function(err) { $rootScope.alerta('Erro', 'Não foi possível carregar os dados, verifique sua internet.'); });
    }

    $rootScope.getClientesGeral = function(){
        var url = $rootScope.url+'cliente/obterchaves?Id='+$localStorage.usuario;
        $http.get(url).then(function(resposta) {

            $localStorage.clientesGeral = [];

            $localStorage.clientesGeral = resposta.data;

            $rootScope.showLoadingPaginas = false;
            $rootScope.showLoading = false;


            //storage.addclientesgeral(resposta);

        }, function(err) { $rootScope.alerta('Erro', 'Não foi possível carregar os dados, verifique sua internet.'); });
    }


    $rootScope.getImagens = function(index, id, tamanho, imagem){
        //var url = $rootScope.url+'catalogo/obter?Id=0';
        //$http.get(url).then(function(resposta) {
            var uri = encodeURI(imagem);   
            var filePath = cordova.file.dataDirectory+id+".jpg";
            console.log("imagem: "+uri+"  id: "+id+"   tamanho: "+tamanho+"  index: "+index);
            console.log("local storage: "+$localStorage.produtos[index].id);

            //$scope.valorSoma = (100/tamanho)/3;

            salvaImagem(uri, filePath, id, tamanho, index);

        //}, function(err) { $rootScope.alerta('Erro', 'Não foi possível carregar os dados, verifique sua internet.'); });
    }


//SALVA FOTO NO STORAGE DO CELULAR -------------------------------------------------------------------------------------------------------------------------------------------------------
    function salvaImagem(uri, filePath, id, tamanho, index) {

        var fileTransfer = new FileTransfer();

        fileTransfer.download(
            uri,
            filePath,
            function(entry) {
                console.log("download complete: " + entry.nativeURL);
                $localStorage.produtos[index].Foto = entry.nativeURL;
                $rootScope.valorProgress= $rootScope.valorProgress+0.185;
                console.log("valor progresso: "+$rootScope.valorProgress+"valor soma: "+$scope.valorSoma);
                $scope.$apply();
                $localStorage.tamanhoProdutos++;
                tamanho--;
                if(tamanho > 0)
                $rootScope.getImagens(index+1, $localStorage.produtos[index+1].id, tamanho, $localStorage.produtos[index+1].Foto);
                else{
                    $rootScope.showLoading = false;
                    $scope.$apply();
                } 

            },
            function(error) {
                if(navigator.connection.type == Connection.NONE){
                    $rootScope.alerta('Erro', 'Não foi possível carregar os dados, verifique sua internet.');
                }else{  
                    console.log("download error source/target/code " + error.source+" / "+error.target+" / "+error.code); 
                    $localStorage.produtos[index].Foto = null;
                    $rootScope.valorProgress= $rootScope.valorProgress+0.185;
                    console.log("valor progresso: "+$rootScope.valorProgress+"valor soma: "+$scope.valorSoma);
                    $scope.$apply();
                    $localStorage.tamanhoProdutos++;
                    tamanho--;
                    if(tamanho > 0)
                    $rootScope.getImagens(index+1, $localStorage.produtos[index+1].id, tamanho, $localStorage.produtos[index+1].Foto);
                    else{
                        $rootScope.showLoading = false;
                        $scope.$apply();
                    }
                }
            }  
        );

    }
//FIM FUNCOES SALVA NO STORAGE----------------------------------------------------------------------------------------------------------------------------------------------------------------------------


})

.controller('homeCtrl', function($scope,$rootScope,$location,$http, storage, $localStorage) {

    
})

.controller('PlaylistCtrl', function($scope, $stateParams) {
});
