angular.module('starter.categorias', [])

.controller('categoriasCtrl', function($scope, $rootScope, $http, $ionicLoading, $localStorage, $timeout) {

    $rootScope.bottomMenu = false;
    $rootScope.logoLogin = false;
    $rootScope.linhaPedidoSelecionada = "";
    $scope.linhas = [];
    $ionicLoading.show();

    $scope.init = function(){
      for (var i=0; i < $localStorage.linhasPedido.length; i++) {
        $scope.linhas.push($localStorage.linhasPedido[i]);
        if(i == $localStorage.linhasPedido.length-1)
                $ionicLoading.hide();
                //$rootScope.showLoadingPaginas = false;
      };
    }
    
    $scope.clickLinha = function(linha){
      $rootScope.linhaPedidoSelecionada = linha;

      var maisDeUmaCategoria = 0;
      var j = 0;

      if($rootScope.linhaPedidoSelecionada.Grade != null){
        for (var i=0; i < $localStorage.categoriasPedido.length; i++) {
              if($rootScope.linhaPedidoSelecionada.id == $localStorage.categoriasPedido[i]['IdDaLinha'] && $localStorage.categoriasPedido[i]['Categoria'] != null){
                  $rootScope.categoriaPedidoSelecionada = $localStorage.categoriasPedido[i]['id'];
                  j++;
                  if(j>1){
                      maisDeUmaCategoria = 1;
                      break;
                  }
              } 
        };

        if(maisDeUmaCategoria == 1 && $rootScope.linhaPedidoSelecionada.Grade != null){
          $rootScope.goto('app.subcategorias');
        }else{
          $rootScope.goto('app.produtospedido');
        }

      }else{
        for (var i=0; i < $localStorage.SubLinhas.length; i++) {

              console.log('linha selecionada: '+$rootScope.linhaPedidoSelecionada.id);
              console.log('Sublinha: '+$localStorage.SubLinhas[i]['IdDaLinha']);

              if($rootScope.linhaPedidoSelecionada.id == $localStorage.SubLinhas[i]['IdDaLinha'] && $localStorage.SubLinhas[i]['SubLinha'] != null){
                  $rootScope.categoriaPedidoSelecionada = $localStorage.SubLinhas[i]['id'];
                  j++;
                  if(j>1){
                    console.log('MAis de um');
                      maisDeUmaCategoria = 1;
                      break;
                  }
              } 
        };

        if(maisDeUmaCategoria == 1){
          $rootScope.goto('app.subcategorias');
        }else{
          $rootScope.goto('app.produtospedido');
        }
      }




    }

    $timeout(function(){
        $scope.init();
    },100);

})