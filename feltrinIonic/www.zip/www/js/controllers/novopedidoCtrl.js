angular.module('starter.novopedido', [])

.controller('novopedidoCtrl', function($rootScope, $scope, $ionicPopup, $ionicHistory, $localStorage, $ionicLoading, $http, $timeout, $ionicModal) {

    $rootScope.bottomMenu = false;
    $rootScope.logoLogin = false;
    $rootScope.bottomMenu = true;
    $scope.showListaProdutos = 1;
    $scope.dadosGerais = [];
    $scope.dados = [];
    $scope.dados2 = [];
    $rootScope.dadosTecnicos = [];
    $scope.showMsgListaPedido = false;
    $ionicLoading.show();
    $scope.valorTotal = 0;

    $scope.ComissaoVariavel = $localStorage.ComissaoVariavel


    console.log($rootScope.cpfClientePedido);
    $scope.cliente = $rootScope.cpfClientePedido+' - '+$rootScope.nomeClientePedido;

    if($localStorage.pedidosSalvos == undefined || $localStorage.pedidosSalvos.length == 0){
        $scope.idPedido = 1;
    }else{
        $scope.idPedido = $localStorage.pedidosSalvos.length+1;
    }

    if($rootScope.cpfClientePedido == undefined){
        $scope.cliente = 'Não selecionado';
    }

    if($rootScope.itensPedido == undefined){
        $rootScope.itensPedido = [];
        $rootScope.objetoComentario = {comentario: ""};
        $ionicLoading.hide();
    }

    if($rootScope.arrayPedido != undefined){
        $rootScope.itensPedido = $rootScope.arrayPedido.Itens;
        
        $rootScope.cpfClientePedido = $rootScope.arrayPedido.Cliente;
        $rootScope.nomeClientePedido = $rootScope.arrayPedido.nomeCliente;
        $scope.cliente = $rootScope.arrayPedido.Cliente+' - '+$rootScope.arrayPedido.nomeCliente;
        $scope.idPedido = $rootScope.arrayPedido.IdDoPedido;
    }


    $rootScope.orientation = screen.orientation.type;

    if($rootScope.larguraTela >= 830){
        $scope.showListaProdutos = 2;
    }
    else
        $scope.showListaProdutos = 1;

    

    // CRIA O ARRAY PARA O Comentario
      $scope.loginData = {};
        
        // CRIA O MODAL CHAMANDO O TEMPLATE
        if($rootScope.larguraTela >= 830){
            $ionicModal.fromTemplateUrl('templates/comentarios.html', {
                scope: $scope,
                animation:'none',
              }).then(function(modal) {
                $scope.modal = modal;
              });
            
        }else{
            $ionicModal.fromTemplateUrl('templates/comentarios.html', {
                scope: $scope,
              }).then(function(modal) {
                $scope.modal = modal;
              });
            
        }
        
      // ABRE O MODAL DE Comentario
      $scope.showComentarios = function() {

            $timeout(function() {
                $scope.modal.show();
            }, 50);
      };

      // ESCONDE O MODAL DE comentario
      $scope.closeModal = function() {
        $scope.modal.hide();
      };




    $scope.init = function(){
        if($rootScope.itensPedido.length == 0){
            $scope.showMsgListaPedido = true;
            $ionicLoading.hide();
        }else{
            for (var i=0; i < $rootScope.itensPedido.length; i++) {
                      
                if($rootScope.itensPedido[i].Grade != null && $rootScope.itensPedido[i].Grade != 'Não possui grade'){
                    var arrayItensGrade = [];
                    arrayItensGrade = $rootScope.itensPedido[i].Itens;  

                    var quantidade = 0;
                    for (var j = 0; j < arrayItensGrade.length; j++) { 
                        console.log(arrayItensGrade[j].Quantidade);
                        if(arrayItensGrade[j].Quantidade != undefined && arrayItensGrade[j].Quantidade != NaN && arrayItensGrade[j].Quantidade != null)
                            quantidade+= parseInt(arrayItensGrade[j].Quantidade);
                    }

                    var PrecoOriginal = $rootScope.itensPedido[i].PrecoDeVenda.toString();
                    $rootScope.itensPedido[i].PrecoOriginal = PrecoOriginal;

                    var PrecoTotal = (parseFloat($rootScope.itensPedido[i].PrecoDeVenda)*(parseInt($rootScope.itensPedido[i].Multiplicador))*parseInt(quantidade)).toFixed(2);
                    PrecoTotal = PrecoTotal.replace('.', ',');
                    $rootScope.itensPedido[i].PrecoTotal = PrecoTotal;

                    $scope.valorTotal+=parseFloat(PrecoTotal).toFixed(2);

                    $rootScope.itensPedido[i].Quantidade = parseInt(quantidade);
                    $rootScope.itensPedido[i].index = i;
                    $scope.dadosGerais.push($rootScope.itensPedido[i]);

                }else{

                    var PrecoOriginal = $rootScope.itensPedido[i].PrecoDeVenda.toString();
                    $rootScope.itensPedido[i].PrecoOriginal = PrecoOriginal;
                    
                    var PrecoTotal = (parseFloat($rootScope.itensPedido[i].PrecoDeVenda)*parseInt($rootScope.itensPedido[i].Quantidade)).toFixed(2);
                    PrecoTotal = PrecoTotal.replace('.', ',');
                    $rootScope.itensPedido[i].PrecoTotal = PrecoTotal;

                    $scope.valorTotal+=parseFloat(PrecoTotal).toFixed(2);
                    
                    $rootScope.itensPedido[i].index = i;
                    $scope.dadosGerais.push($rootScope.itensPedido[i]);



                }
                

                if(i == $rootScope.itensPedido.length-1){
                    $timeout(function() {   
                        $scope.carregarDados();
                    }, 400);
                }
            };
        }
    }

    $scope.carregarDados = function(){ 

        var meio = parseInt($scope.dadosGerais.length/2);

        if($scope.dadosGerais.length <= 1){
            for (var i=0; i < $scope.dadosGerais.length; i++) {
                if(i == $scope.dadosGerais.length-1)
                    $ionicLoading.hide();
                //if($rootScope.categoriaSelecionada == $scope.dadosGerais[i]['IdDaCategoria'])
                $scope.dados.push($scope.dadosGerais[i]);
            };
        }else{
            for (var i=0; i < meio; i++) {
                //if($rootScope.categoriaSelecionada == $scope.dadosGerais[i]['IdDaCategoria'])
                $scope.dados.push($scope.dadosGerais[i]);
            };

            for (var i=meio; i < $scope.dadosGerais.length; i++) {
                if(i == $scope.dadosGerais.length-1){
                    $ionicLoading.hide();
                    $rootScope.produto = $scope.dados[0];
                }
                
                //if($rootScope.categoriaSelecionada == $scope.dadosGerais[i]['IdDaCategoria'])
                $scope.dados2.push($scope.dadosGerais[i]);
            };
        }

        
    }

    $scope.clickClientes = function(){
        $rootScope.buscaClientesPedido = 1;
        $rootScope.goto('app.buscaclientes');
    }


    $scope.longClickDelete = function(item, index){
        var myPopup = $ionicPopup.show({
          title: 'Deseja deletar esse item?',
          scope: $scope,
          buttons: [
            
            {
              text: 'Sim',
              type: 'button-positive',
              onTap: function(e) {
                //alert('Tapped!'+res);
                if($rootScope.itensPedido.length == 1)
                    $rootScope.itensPedido = [];
                else
                    var removed = $rootScope.itensPedido.splice(index+1, 1);
                
                $timeout(function(){
                  $scope.dadosGerais = [];
                  $scope.dados = [];
                  $scope.dados2 = [];
                  $scope.init();
                  myPopup.close();
                }, 200);                
              }
            },
            {
              text: 'Não',
              type: 'button-calm',
              onTap: function(e) {
                //$scope.getCamera();
              }
            }
          ]
        });

    }

    $scope.blurPrecoUn = function(valorUn, valorTotal, Quantidade, i){

        console.log('index: '+i);

        var valorTotalFloat = parseFloat(valorTotal);
        var valorUnFloat = parseFloat(valorUn);
        Quantidade = parseInt(Quantidade);


        if(valorUnFloat >= parseFloat($rootScope.itensPedido[i].PrecoOriginal)){

            if($rootScope.itensPedido[i].Grade != null){
                $rootScope.itensPedido[i].PrecoTotal  = (valorUnFloat*parseInt($rootScope.itensPedido[i].Multiplicador))*Quantidade;
            }else{
                $rootScope.itensPedido[i].PrecoTotal  = valorUnFloat*Quantidade;
            }

        }else{
            $rootScope.alerta('', 'O valor deve ser igual ou maior que o valor original');
            console.log('valor original: '+parseFloat($rootScope.itensPedido[i].PrecoOriginal));
            $rootScope.itensPedido[i].PrecoDeVenda  = parseFloat($rootScope.itensPedido[i].PrecoOriginal);

        }

        

    }

    $scope.blurPrecoTotal = function(valorUn, valorTotal, Quantidade, i){

        console.log('index: '+i);

        var valorTotalFloat = parseFloat(valorTotal);
        var valorUnFloat = parseFloat(valorUn);
        Quantidade = parseInt(Quantidade);


        console.log(parseFloat($rootScope.itensPedido[i].PrecoOriginal));
        console.log('total: '+valorTotalFloat);
        console.log('total: '+valorUnFloat);
        console.log('multipl: '+$rootScope.itensPedido[i].Multiplicador);

        if($rootScope.itensPedido[i].Grade != null){
            console.log( (parseFloat($rootScope.itensPedido[i].PrecoOriginal)*$rootScope.itensPedido[i].Multiplicador)*Quantidade);
            if(valorTotalFloat >= (parseFloat($rootScope.itensPedido[i].PrecoOriginal)*parseInt($rootScope.itensPedido[i].Multiplicador))*Quantidade){
                $rootScope.itensPedido[i].PrecoDeVenda = valorTotalFloat/Quantidade;
            }else{
                $rootScope.alerta('', 'O valor deve ser igual ou maior que o valor original');
                $rootScope.itensPedido[i].PrecoTotal  = (parseFloat($rootScope.itensPedido[i].PrecoOriginal)*parseInt($rootScope.itensPedido[i].Multiplicador))*Quantidade;

            }
        }else{
            if(valorTotalFloat >= parseFloat($rootScope.itensPedido[i].PrecoOriginal)*Quantidade){
                $rootScope.itensPedido[i].PrecoDeVenda = valorTotalFloat/Quantidade;
            }else{
                $rootScope.alerta('', 'O valor deve ser igual ou maior que o valor original');

                $rootScope.itensPedido[i].PrecoTotal  = parseFloat($rootScope.itensPedido[i].PrecoOriginal)*Quantidade;

            }
        }

    }

    $scope.salvarPedido = function(){

        console.log($rootScope.objetoComentario.comentario);

        if($rootScope.cpfClientePedido == undefined){
            $rootScope.alerta('Salvar Pedido', 'Você deve selecionar um cliente.');
        }else if($rootScope.itensPedido.length == 0){
            $rootScope.alerta('Salvar Pedido', 'Selecione ao menos um item.');
        }
        else{



            var myPopup = $ionicPopup.show({
              title: 'O que você deseja fazer?',
              scope: $scope,
              buttons: [
                {
                  text: 'Salvar e Enviar',
                  type: 'button-positive',
                  onTap: function(e) {
                       $scope.salvaPedidoOffline('Aguardando envio'); 
                  }
                },
                {
                  text: 'Salvar Rascunho',
                  type: 'button-calm',
                  onTap: function(e) {
                    $scope.salvaPedidoOffline('Rascunho'); 
                  }
                }
              ]
            });
        } 
        

    }

    $scope.salvaPedidoOffline = function(tipo){

        $ionicLoading.show();


        var arrayItens = [];
        for (var i = 0; i < $rootScope.itensPedido.length; i++){

            if($rootScope.itensPedido[i].Grade != null && $rootScope.itensPedido[i].Grade != 'Não possui grade'){

                var arrayItensGrade = [];
                arrayItensGrade = $rootScope.itensPedido[i].Itens; 
                var enumeradorSimouNao = 1;

                var itens = []; 

                console.log(arrayItensGrade);

                var quantidade = 0;
                for (var j = 0; j < arrayItensGrade.length; j++) { 
                    itens.push({ 
                        IdDoPedido: $scope.idPedido, 
                        CodigoItem: arrayItensGrade[j].Grade, 
                        CodigoGrade: arrayItensGrade[j].CodigoDoItem, 
                        Quantidade: arrayItensGrade[j].Quantidade });
                }

                arrayItens.push({IdDoPedido: $scope.idPedido, CodigoItem: arrayItensGrade[0].Grade, Quantidade: $rootScope.itensPedido[i].Quantidade, PrecoOriginal: parseFloat($rootScope.itensPedido[i].PrecoDecimal), Preco: parseFloat($rootScope.itensPedido[i].PrecoDeVenda), Grade: enumeradorSimouNao, Itens: itens});


            }else{
                var enumeradorSimouNao = 0;
                arrayItens.push({IdDoPedido: $scope.idPedido, CodigoItem: $rootScope.itensPedido[i].CodigoDoItem, Quantidade: $rootScope.itensPedido[i].Quantidade, PrecoOriginal: parseFloat($rootScope.itensPedido[i].PrecoOriginal), Preco: parseFloat($rootScope.itensPedido[i].PrecoDeVenda), Grade: enumeradorSimouNao, Itens: []});
            }
        }

        var arrayPedido = { 
            IdDoPedido: $scope.idPedido, 
            Usuario: $localStorage.usuario,
            Cliente: $rootScope.cpfClientePedido,
            IdDoVendedor: $localStorage.usuario,
            Comentarios: $rootScope.objetoComentario.comentario,
            Itens: arrayItens
        };

        var arraySalvarPedido = {
            Nome: "", 
            tipo: tipo,
            IdDoPedido: $scope.idPedido, 
            Usuario: $localStorage.usuario,
            Cliente: $rootScope.cpfClientePedido,
            nomeCliente: $rootScope.nomeClientePedido,
            IdDoVendedor: $localStorage.usuario,
            Comentarios: $rootScope.objetoComentario.comentario,
            Itens: $rootScope.itensPedido
        };

        if($rootScope.arrayPedido != undefined){
            var index = $rootScope.arrayPedido.index;
            arraySalvarPedido.tipo = $localStorage.pedidosSalvos[index].tipo;
        }   

        console.log(JSON.stringify(arrayPedido));

        console.log(arraySalvarPedido);

        console.log('array pedido (tem que ser undefined): '+$rootScope.arrayPedido);
        

        
        if(arraySalvarPedido.tipo == 'Aguardando envio'){
            $scope.enviaPedidoBanco(arrayPedido, arraySalvarPedido);
        }else if(arraySalvarPedido.tipo == 'Sincronizado'){
            $rootScope.alerta('Salvar Pedido', 'O pedido já foi sincronizado.');
            $ionicLoading.hide();
        }else{

            $scope.cliente = 'Não selecionado';
            $rootScope.cpfClientePedido = undefined;
            $rootScope.objetoComentario = {comentario: ""};
            $rootScope.itensPedido = [];

            if($rootScope.arrayPedido == undefined){
                $localStorage.pedidosSalvos.push(arraySalvarPedido);
            }else{
                var index = $rootScope.arrayPedido.index;
                $localStorage.pedidosSalvos[index] = arraySalvarPedido;
            }
            $rootScope.alerta('Salvar Pedido', 'Rascunho salvo com sucesso.');
            $ionicHistory.goBack(-1);
            $ionicLoading.hide();
        }

    }

    $scope.enviaPedidoBanco = function(array, arraySalvarPedido){

            $rootScope.login($localStorage.usuario , $localStorage.senha, 1);

            $scope.cliente = 'Não selecionado';
            $rootScope.cpfClientePedido = undefined;
            $rootScope.objetoComentario = {comentario: ""};
            $rootScope.itensPedido = [];

            var url = $rootScope.url+'pedido/novo';
            $http.post(url, array).then(function(resposta) {

                console.log(resposta);
                $rootScope.alerta('Salvar Pedido', 'Pedido salvo com sucesso.');

                arraySalvarPedido.tipo = 'Sincronizado';
                if($rootScope.arrayPedido == undefined){
                    $localStorage.pedidosSalvos.push(arraySalvarPedido);
                }else{
                    var index = $rootScope.arrayPedido.index;
                    $localStorage.pedidosSalvos[index] = arraySalvarPedido;
                }
                $ionicHistory.goBack(-1);
                $ionicLoading.hide();

            }, function(err) {
                arraySalvarPedido.tipo = 'Aguardando envio';
                if($rootScope.arrayPedido == undefined){
                    $localStorage.pedidosSalvos.push(arraySalvarPedido);
                }else{
                    var index = $rootScope.arrayPedido.index;
                    $localStorage.pedidosSalvos[index] = arraySalvarPedido;
                }
                $ionicHistory.goBack(-1);
                $ionicLoading.hide();

                $rootScope.alerta('Erro', 'Não foi possível enviar os dados, o pedido será salvo, entre em "Meus Pedidos" para tentar enviar novamente. '); 
            });
    }

    $scope.telaDetalhesLado = function(){
        console.log($rootScope.orientation.indexOf('landscape'));
        if($rootScope.orientation.indexOf('landscape') != -1 ){
          $scope.showListaProdutos = 2;
        }
        else{
          $scope.showListaProdutos = 1;
        }
        $scope.$apply();
    }

    $timeout(function(){
        $scope.init();
    },100);


})