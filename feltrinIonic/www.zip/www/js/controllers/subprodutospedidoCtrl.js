angular.module('starter.subprodutospedido', [])

.controller('subprodutospedidoCtrl', function($rootScope, $scope, $localStorage, $ionicLoading, $http, $timeout, $ionicModal) {

    $rootScope.bottomMenu = false;
    $rootScope.logoLogin = false;
    $scope.showListaProdutos = 1;
    $scope.dadosGerais = [];
    $scope.dados = [];
    $scope.dados2 = [];
    $ionicLoading.show();

    $rootScope.orientation = screen.orientation.type;

    if($rootScope.larguraTela >= 830){
        $scope.showListaProdutos = 2;
    }
    else
        $scope.showListaProdutos = 1;

 
    $scope.init = function(){

          var arrayItensCategoria = [];


          for (var i=0; i < $rootScope.ItensSubgrupo.length+1; i++) {

                if(i == $rootScope.ItensSubgrupo.length){
                    console.log(i);
                    $scope.carregarDados();
                }

                if($rootScope.ItensSubgrupo[i] != undefined){
                    //console.log('codigo item: '+JSON.stringify($rootScope.ItensSubgrupo[i]));

                    var condicao = {CodigoDoItem: $rootScope.ItensSubgrupo[i].CodigoDoItem, PrecoDeVenda: $rootScope.ItensSubgrupo[i].PrecoDeVenda};
                    function getItem(item) {
                        for(var key in condicao) {
                            if(item[key] === undefined || item[key] != condicao[key])
                                return null;
                        }
                        return item;
                    }
                    filter = $rootScope.itensPedido.filter(getItem);
                    //console.log(filter);


                    if(filter != null && filter.length > 0 && filter[0].Quantidade != undefined)
                        $rootScope.ItensSubgrupo[i].Quantidade = filter[0].Quantidade;
                    else
                       $rootScope.ItensSubgrupo[i].Quantidade = null; 

                    $scope.dadosGerais.push($rootScope.ItensSubgrupo[i]);
                }


                
          };


    }



    $scope.carregarDados = function(){ 

        var meio = parseInt($scope.dadosGerais.length/2);

        if($scope.dadosGerais.length <= 1){
            for (var i=0; i < $scope.dadosGerais.length; i++) {
                if(i == $scope.dadosGerais.length-1)
                    $ionicLoading.hide();
                $scope.dados.push($scope.dadosGerais[i]);
            };
        }else{
            for (var i=0; i < meio; i++) {
                $scope.dados.push($scope.dadosGerais[i]);
            };

            for (var i=meio; i < $scope.dadosGerais.length; i++) {
                if(i == $scope.dadosGerais.length-1){
                    $ionicLoading.hide();
                    $rootScope.produto = $scope.dados[0];
                }
                $scope.dados2.push($scope.dadosGerais[i]);
            };
        }

        
    }


    $scope.changeItemPedido = function(item){
        if(item.Quantidade != 0 && item.Quantidade != "" && item.Quantidade != null){
            var filter = null;
            var condicao = {CodigoDoItem: item.CodigoDoItem, PrecoDeVenda: item.PrecoDeVenda};
            function getItem(item) {
                for(var key in condicao) {
                    if(item[key] === undefined || item[key] != condicao[key])
                        return null;
                }
                return item;
            }
            filter = $rootScope.itensPedido.filter(getItem);
            console.log(filter);
            if(filter == null || filter.length == 0){
                console.log('adiciona item: '+item);
                $rootScope.itensPedido.push(item);
            }else{
                console.log('soma item: '+item.Quantidade);
                filter[0].Quantidade=item.Quantidade;
            }
        }

    }

    window.addEventListener("orientationchange", function(){
        console.log(screen.orientation.type); // e.g. portrait 
        $rootScope.orientation = screen.orientation.type;
        $scope.telaDetalhesLado();
        $rootScope.larguraTela = window.screen.width+30;
        //alert($rootScope.larguraTela);
    });

    $scope.telaDetalhesLado = function(){
        console.log($rootScope.orientation.indexOf('landscape'));
        if($rootScope.orientation.indexOf('landscape') != -1 ){
          $scope.showListaProdutos = 2;
        }
        else{
          $scope.showListaProdutos = 1;
        }
        $scope.$apply();
    }


    $timeout(function(){
        $scope.init();
    },100);

})